#!/bin/bash
. ok-config.conf
echo $OPENKEEPER_CLI_INSTALL_PATH
