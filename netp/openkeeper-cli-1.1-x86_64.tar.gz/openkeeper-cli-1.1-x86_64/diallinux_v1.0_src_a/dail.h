#ifndef _DAIL_H_
#define _DAIL_H_
#include<iostream>
#include<string>
#include<cstring>
#include<cstdlib>
#include <fstream>
#include<unistd.h>
#include"CXKUsername.h"

using namespace std;

#endif //_DAIL_H_
