#ifndef _FUNCTION_
#define _FUNCTION_
#include "head.h"

static long m_lasttimec;
extern const unsigned char RADIUS[];

char *make_realusername(const unsigned char *temp)
{
     time_t m_time;
     long m_time1c;
     long m_time1convert;
     unsigned char ss[4] =
	  {
	       0,0,0,0
	  };		//源数据1,对m_time1convert进行计算得到格式符源数据
     unsigned char ss2[4] =
	  {
	       0,0,0,0
	  };		//md5加密参数的一部分,m_time1c的字符形式
     unsigned char *strS1 = (unsigned char *)malloc(MAXSIZE);
     unsigned char *m_formatstring = (unsigned char *)malloc(MAXSIZE);
     time(&m_time);
     {
	  long long t = m_time;
	  t *= 0x66666667;
	  t >>= 0x20;
	  t >>= 0x01;
	  m_time1c = (long) t;
     }
     if (m_time1c <= m_lasttimec)
     {
	  m_time1c = m_lasttimec + 1;
     }
     m_lasttimec = m_time1c;
     {
	  long t;
	  t = m_time1c;
	  ss2[3] = (t & 0xFF);
	  ss2[2] = (t & 0xFF00) / 0x100  ;
	  ss2[1] = (t & 0xFF0000) / 0x10000;
	  ss2[0] = (t & 0xFF000000) / 0x1000000;
	  {
	       //strS1必须用自加得到，真接加出问题
	       int i;
	       for (i = 0; i < 4; i++)
	       {
	  	    /* strS1 += ss2[i]; */
		    strS1[i] = ss2[i];
	       }
	  }
     }
     {
	  int t, t1, t2, t3;
	  t = m_time1c;
	  t1 = t;
	  t2 = t;
	  t3 = t;
	  t3 = t3 << 0x10;
	  t1 = t1 & 0x0FF00;
	  t1 = t1 | t3;
	  t3 = t;
	  t3 = t3 & 0x0FF0000;
	  t2 = t2 >> 0x10;
	  t3 = t3 | t2;
	  t1 = t1 << 0x08;
	  t3 = t3 >> 0x08;
	  t1 = t1 | t3;
	  m_time1convert = t1;
     }
     {
	  long t;
	  t = m_time1convert;
	  ss[3] = (t & 0xFF);
	  ss[2] = (t & 0xFF00) / 0x100  ;
	  ss[1] = (t & 0xFF0000) / 0x10000;
	  ss[0] = (t & 0xFF000000) / 0x1000000;
     }

     unsigned char pp[4] =
	  {
	       0,0,0,0
	  };
     {
	  int i = 0, j = 0, k = 0;
	  for (i = 0; i < 0x20; i++)
	  {
	       j = i / 0x8;
	       k = 3 - (i % 0x4);
	       pp[k] *= 0x2;
	       if (ss[j] % 2 == 1)
	       {
		    pp[k]++;
	       }
	       ss[j] /= 2;
	  }
     }
     unsigned char pf[6] =
	  {
	       0,0,0,0,0,0
	  };
     //子函数////////////////////////////
     {
	  if(sizeof(int)==2)
	  {
	       int t1, t2;
	       t1 = pp[3];
	       t1 /= 0x4;
	       pf[0] = t1;
	       t1 = pp[3];
	       t1 = t1 & 0x3;
	       t1 *= 0x10;
	       pf[1] = t1;
	       t2 = pp[2];
	       t2 /= 0x10;
	       t2 = t2 | t1;
	       pf[1] = t2;
	       t1 = pp[2];
	       t1 = t1 & 0x0F;
	       t1 *= 0x04;
	       pf[2] = t1;
	       t2 = pp[1];
	       t2 /= 0x40;
	       t2 = t2 | t1;
	       pf[2] = t2;
	       t1 = pp[1];
	       t1 = t1 & 0x3F;
	       pf[3] = t1;
	       t2 = pp[0];
	       t2 /= 0x04;
	       pf[4] = t2;
	       t1 = pp[0];
	       t1 = t1 & 0x03;
	       t1 *= 0x10;
	       pf[5] = t1;
	  }
	  else{
	       short t1,t2 ;
	       t1 = pp[3];
	       t1 /= 0x4;
	       pf[0] = t1;
	       t1 = pp[3];
	       t1 = t1 & 0x3;
	       t1 *= 0x10;
	       pf[1] = t1;
	       t2 = pp[2];
	       t2 /= 0x10;
	       t2 = t2 | t1;
	       pf[1] = t2;
	       t1 = pp[2];
	       t1 = t1 & 0x0F;
	       t1 *= 0x04;
	       pf[2] = t1;
	       t2 = pp[1];
	       t2 /= 0x40;
	       t2 = t2 | t1;
	       pf[2] = t2;
	       t1 = pp[1];
	       t1 = t1 & 0x3F;
	       pf[3] = t1;
	       t2 = pp[0];
	       t2 /= 0x04;
	       pf[4] = t2;
	       t1 = pp[0];
	       t1 = t1 & 0x03;
	       t1 *= 0x10;
	       pf[5] = t1;
	  }
     }
     {
	  int i;
	  for (i = 0; i < 6; i++)
	  {
	       pf[i] += 0x20;
	       if ((pf[i]) >= 0x40)
	       {
		    pf[i]++;
	       }
	  }
     }
     {
	  int i;
	  for (i = 0; i < 6; i++)
	  {
	       m_formatstring[i] = pf[i];
	  }
     }
     unsigned char *username_ws = (unsigned char*)malloc(MAXSIZE);
     memset(username_ws,0,MAXSIZE);
     find_username_without_school((char*)temp,&username_ws);

     char *strInput = (char *)malloc(MAXSIZE);
     memset(strInput,0,MAXSIZE);
     char temp_username[100];
     strcpy(strInput,strS1);
     strcat(strInput,username_ws);
     strcat(strInput,RADIUS);
     strcpy(temp_username,strInput);
     

     /* md5 encrypton  */
     MD5_CTX md5;
     MD5Init(&md5);         
     int i;
     unsigned char digest[16];    
     MD5Update(&md5,temp_username,strlen((char *)temp_username));
     MD5Final(&md5,digest);        
#if 0 
     for(i=0;i<16;i++)
     {
	  char t[3];
	  sprintf(t,"%02x",digest[i]);
	  printf("t = %s\n",t);
     }
     printf("\n");
#endif
     char t[3];
     sprintf(t,"%02x",digest[0]);
     /* md5 encrypton  */
     char *real_username = (char*)malloc(MAXSIZE);
     strcpy(real_username,"\r\n");
     strcat(real_username,m_formatstring);
     strcat(real_username,t);
     strcat(real_username,temp);
     
     free(strInput);
     free(username_ws);
     free(strS1);
     free(m_formatstring);
     return (char *)real_username;
}

int find_username_without_school(char *s,unsigned char **r)
/* 找到除了@cqupt之外的username */
{
     unsigned char *temp = *r;
     for (;*s != '\0' && *s != '@' ;s++)
     {
     	  *temp = *s;
	  temp++;
     }
     return 0;
}
#endif
