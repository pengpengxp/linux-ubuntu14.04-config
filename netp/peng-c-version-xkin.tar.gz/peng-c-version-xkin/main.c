#ifndef _MAIN_
#define _MAIN_
#include "head.h"

/* 填写你的用户名 */
const unsigned char O_username[] = "username@cqupt";

const unsigned char RADIUS[] = "cqxinliradius002";

int main(int argc, char *argv[])
{
     char *real_username;
     real_username = make_realusername(O_username);
     printf("%s\n",real_username);
     free(real_username);
     return 0;
}
#endif
