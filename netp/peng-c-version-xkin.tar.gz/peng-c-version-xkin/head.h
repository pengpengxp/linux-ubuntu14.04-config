#ifndef _HEAD_
#define _HEAD_
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "md5.h"

#define MAXSIZE 1024

char *make_realusername(const unsigned char *temp);
int find_username_without_school(char *s,unsigned char **r);
#endif
